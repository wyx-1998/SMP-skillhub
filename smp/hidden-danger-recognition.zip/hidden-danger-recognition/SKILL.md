---
name: hidden-danger-recognition
description: 安全隐患图像识别。
requires:
  - smp-root-rules

---

# 安全隐患图像识别

> 文件校验 → 接口识别 → 解析结果 → 输出。只识别，不保存。

## 文件校验

| 校验项 | 规则                     |
| ------ | ------------------------ |
| 路径   | 文件必须存在且可读       |
| 后缀   | 仅 `.jpg` `.jpeg` `.png` |
| 大小   | 大于 0 字节              |

校验失败就停。

## 工具

```yaml
hidden_danger_detect:
  input:
    filepath: string   # 必填，图片绝对路径
    timeout: int       # 可选，默认 120s
  output:
    success: bool
    items: array
      - description: string
        request: string
    error: string
```

## 请求

```bash
curl -X POST http://101.204.230.42:2044/ImageReco_HiddenDanger/ \
  -F "imgfile=@<文件路径>" \
  --connect-timeout 30 \
  --max-time 120
```

## 结果解析

| 条件                                    | 处理                               |
| --------------------------------------- | ---------------------------------- |
| HTTP 非 200 / 非 JSON                   | 返回错误                           |
| 缺少 `analysisDetails.content` / 空数组 | 返回空结果                         |
| 正常                                    | `data` = `analysisDetails.content` |

## 输出

`summary`：一句话识别结果或错误。`data`：`analysisDetails.content` 数组，失败时为 `[]`。其余遵守 `smp-root-rules`。

`button`：按钮数组，输出 `[{"label":"去随手拍登记","value":"setDescription"}]`。